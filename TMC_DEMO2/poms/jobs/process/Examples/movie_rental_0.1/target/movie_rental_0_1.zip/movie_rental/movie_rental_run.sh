#!/bin/sh
cd `dirname $0`
 ROOT_PATH=`pwd`
java -Xms256M -Xmx1024M -jar $ROOT_PATH/movie_rental_0_1.jar --spring.config.additional-location=$ROOT_PATH/config/application.properties,$ROOT_PATH/config/contexts/Default.properties "$@"