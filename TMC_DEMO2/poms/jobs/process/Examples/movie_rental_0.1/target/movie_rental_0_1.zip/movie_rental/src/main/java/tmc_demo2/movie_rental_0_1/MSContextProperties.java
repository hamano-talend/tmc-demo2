package tmc_demo2.movie_rental_0_1;

import org.springframework.boot.context.properties.ConfigurationProperties;
	
@ConfigurationProperties
public class MSContextProperties extends ContextProperties { }

