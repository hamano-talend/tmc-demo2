package tmc_demo2.movie_rental_0_1;

        import java.io.BufferedInputStream;
        import java.io.File;
        import java.io.FileInputStream;
        import java.io.InputStream;
        import java.net.URI;
        import java.net.URL;
        import java.nio.file.Files;
        import java.nio.file.Path;
        import java.nio.file.Paths;
        import java.util.HashMap;
        import java.util.List;
        import java.util.Map;
        import java.util.Properties;
        import java.util.jar.JarEntry;
        import java.util.jar.JarInputStream;
        import org.apache.cxf.Bus;
        import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
        import org.apache.cxf.transport.servlet.CXFServlet;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.boot.ApplicationArguments;
        import org.springframework.boot.ApplicationRunner;
        import org.springframework.boot.SpringApplication;
        import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
        import org.springframework.boot.autoconfigure.SpringBootApplication;
        import org.springframework.boot.context.properties.ConfigurationProperties;
        import org.springframework.boot.context.properties.EnableConfigurationProperties;
        import org.springframework.boot.web.servlet.ServletRegistrationBean;
        import org.springframework.context.ApplicationContext;
        import org.springframework.context.annotation.Bean;
        import org.springframework.context.annotation.Configuration;
        import org.springframework.context.annotation.ImportResource;
        import org.springframework.core.env.Environment;
/**
 * Job: movie_rental Purpose: <br>
 * Description: ESB microservice launcher application for movie_rental<br>
 * @author Hamano, Masaki
 * @version 0.1
 * @status 
 */

@SpringBootApplication
@EnableConfigurationProperties(MSContextProperties.class)
@Configuration
@ImportResource({ "classpath:META-INF/cxf/cxf.xml" })
public class App extends movie_rental implements ApplicationRunner {

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(movie_rental.class);
	

    @Autowired
    Environment env;

    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    private MSContextProperties wiredContext;

    public App() {
        setRunInTalendEsbRuntimeContainer(true);
        setRunInDaemonMode(false);
       
    }
	
    public static void main( String[] args )
    {
        String[] resetArgs = resetArgs(args);
        SpringApplication.run(App.class, resetArgs);
    }

    @Bean
    public org.apache.cxf.endpoint.Server restServer() {
        context = wiredContext;
        new ContextProcessing().processAllContext();
        Thread4RestServiceProviderEndpoint thread4RestServiceProviderEndpoint = new Thread4RestServiceProviderEndpoint(this,
                getCXFRSEndpointAddress(getRestEndpoint()));
        JAXRSServerFactoryBean sf = thread4RestServiceProviderEndpoint.getJAXRSServerFactoryBean();
        sf.setBus(springBus());
        
        sf.getFeatures().add(new org.apache.cxf.metrics.MetricsFeature(new org.apache.cxf.metrics.codahale.CodahaleMetricsProvider(sf.getBus())));
        
        //List providers = sf.getProviders();
        // JAASAuthenticationFilter jaasAuthenticationFilter = new JAASAuthenticationFilter();
        // jaasAuthenticationFilter.setContextName("karaf");
        // providers.add(jaasAuthenticationFilter);
        // sf.setProviders(providers);
        

        thread4RestServiceProviderEndpoint.run();
        
        return thread4RestServiceProviderEndpoint.getServer();
        
    }
    
	@Bean
	public com.codahale.metrics.MetricRegistry metricRegistry() {
		return new com.codahale.metrics.MetricRegistry();
	}

	@Bean(initMethod = "start", destroyMethod = "stop")
	public com.codahale.metrics.jmx.JmxReporter jmxReporter() {
		return com.codahale.metrics.jmx.JmxReporter.forRegistry(metricRegistry()).inDomain("org.apache.cxf").createsObjectNamesWith(new com.codahale.metrics.jmx.ObjectNameFactory() {
            public javax.management.ObjectName createName(String type, String domain, String name) {
                try {
                	if(name.startsWith("org.apache.cxf")){
                		return new javax.management.ObjectName(name);
                	}else{
                		return new com.codahale.metrics.jmx.DefaultObjectNameFactory().createName(type, domain, name);
                	}
                    
                } catch (javax.management.MalformedObjectNameException e) {
                    throw new RuntimeException(e);
                }
            }
        }).build();
	}
	
    @Bean
    public ServletRegistrationBean servletRegistrationBean(ApplicationContext context) {
        return new ServletRegistrationBean(new CXFServlet(), "/services/*");
    }
	
    private String[] mainArgs = new String[] {};

    public void run(ApplicationArguments args) throws Exception {
        String[] ma = args.getSourceArgs();
        mainArgs = ma;
        context = wiredContext;
        runJobInTOS(mainArgs);
    }
    
    public InputStream getConfigLocation(String fileName) {
        InputStream stream = null;

        String configFile = "config/" + fileName;

        String configPath = this.env.getProperty("spring.config.additional-location");

        String file = "";
        if (configPath != null) {
            file = configPath + File.separator + fileName;
        } else {
            file = System.getProperty("user.dir") + File.separator + configFile;
        }
        File usersfile = new File(file);
        if (usersfile.exists()) {
            try {
                stream = new FileInputStream(file);
            } catch (Exception e) {
                stream = getClass().getClassLoader().getResourceAsStream(configFile);
            }
        } else {
            stream = getClass().getClassLoader().getResourceAsStream(configFile);
        }
        return stream;
    }    
    
    private static void loadConfig(Map<String, String> argsMap, String configName, String configValue) {
        String configFileValue = "classpath:config/" + configValue;
        if (argsMap.get(configName) == null) {
            if (argsMap.get("--spring.config.additional-location") == null) {
                argsMap.put(configName, configFileValue);
            } else {
                String value = (String) argsMap.get("--spring.config.additional-location") + File.separator + configValue;
                if (new File(value).exists()) {
                    argsMap.put(configName, "file:" + value);
                } else if (((String) argsMap.get("--spring.config.additional-location")).contains(":")) {
                    try {
                        if (new File(new URI(value)).exists()) {
                            argsMap.put(configName, value);
                        } else {
                            argsMap.put(configName, configFileValue);
                        }
                    } catch (Exception e) {
                        argsMap.put(configName, configFileValue);
                    }
                } else {
                    argsMap.put(configName, configFileValue);
                }
            }
        }
    }
    
    private static String[] resetArgs(String... args) {
        Map<String, String> argsMap = new HashMap<String, String>();

        for (int i = 0; i < args.length; i++) {
            String[] kv = args[i].split("=");
            if(kv.length > 1) {           
            	argsMap.put(kv[0], args[i].substring(args[i].indexOf("=") + 1));
            }
        }

        if (argsMap.get("--spring.config.additional-location") != null) {
            System.setProperty("spring.config.additional-location", argsMap.get("--spring.config.additional-location"));
        }
        loadConfig(argsMap, "--spring.banner.location", "banner.txt");

        argsMap.put("--spring.main.allow-bean-definition-overriding", "true");

        if (argsMap.get("--camel.springboot.typeConversion") == null) {
            argsMap.put("--camel.springboot.typeConversion", "false");
        }

        String[] resetArgs = new String[argsMap.size()];

        java.util.Set<String> keySet = argsMap.keySet();

        int idx = 0;

        for (String key : keySet) {
            resetArgs[idx] = key + "=" + argsMap.get(key);
            idx++;
        }

        return resetArgs;
    }
    
    public String getCXFRSEndpointAddress(String endpointUrl) {
        if (endpointUrl != null && !endpointUrl.trim().isEmpty() && !endpointUrl.contains("://")) {
            if (endpointUrl.startsWith("/services")) {
                endpointUrl = endpointUrl.substring("/services".length());
            }
            if (!endpointUrl.startsWith("/")) {
                endpointUrl = '/' + endpointUrl;
            }
        }
        return endpointUrl;
    }
    
    @org.springframework.context.annotation.Bean(name = "cxf")
    public org.apache.cxf.bus.spring.SpringBus springBus() {
    	return new org.apache.cxf.bus.spring.SpringBus();
    }



         private class ContextProcessing {
                private void processContext_0() {
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }
}
